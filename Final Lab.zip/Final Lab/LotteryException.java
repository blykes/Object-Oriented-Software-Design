package edu.cuny.csi.csc330.lab5A;

public class LotteryException extends Exception{
	
	// static publicly defined error codes 
	public static int	UNSET = 0; 
	public static int	INVALID_GAMETYPE = 1; 
	public static int INVALID_POOL1 = 2; 
	public static int	INVALID_POOL2 = 3;

	public static String[]  MESSAGE = { 
			"Code Unspecified", 
			"Invalid Game Type", 
			"Invalid Pick Pool 1", 
			"Invalid Pick Pool 2"
	} ;
	
	protected int code;
	
	private LotteryException() { ; }
		// TODO Auto-generated constructor stub
	
	
	 public LotteryException(String m) { 
	    	super(m); 
	    } 
	    
	    // with thrower message and code 
	    public LotteryException(String message, int code) { 
	    	super(message);
	    	this.code = code;
	    } 
	    
		public int getCode() { 
			return code;
		}
		
		
	
	public void on() throws LotteryException  {
		
		//if(this.isOn() )  
			throw new LotteryException("on() method",  LotteryException.INVALID_GAMETYPE);  
		
		//Date now = new Date(); 
	} 
	
	private static LotteryException LotteryException(String string) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
		public String toString() {
			return "LotteryException [code=" + code + ", toString()=" + super.toString() + "]\n" + MESSAGE[code];
		}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//No Code
		LotteryException ex = LotteryException("Lotto Excetption Message ...  ");
		System.out.println("Ex: " + ex);
		
		//With Code
		ex = new LotteryException("Lotto Exception Message ... ", LotteryException.INVALID_GAMETYPE);
		System.out.println("Ex: " + ex);
		
		

	}
	
	
}
