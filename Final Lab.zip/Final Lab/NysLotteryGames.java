/**
 * LAB 5 (1b) - Sweetmillion Game modified for other games. 
 */

package edu.cuny.csi.csc330.lab5A;

import java.util.*;
import java.io.*;
import java.lang.*;
import edu.cuny.csi.csc330.*;
import edu.cuny.csi.csc330.lab1.Randomizer;
import edu.cuny.csi.csc330.lab5A.LotteryException;

public class NysLotteryGames 
{
	//Constants for all games
	public final static int DEFAULT_GAME_COUNT = 5;
	private final static int SELECTION_POOL_SIZE = 40;
	private final static int SELECTION_COUNT = 6;
	
	private Randomizer randomizer; 
	private int gameCount = DEFAULT_GAME_COUNT;
	private String seller; 
	private String gameName; 
	private static int selectionPoolSize;
	private static String poolSize2;
	private int selectionCount; 
	
	public int select;
	

	//static {
		//exceptionMethod(selectionPoolSize, poolSize2, gameName) throws LotteryException;
	//}
	public NysLotteryGames(String gameType, int numberOfGames, int selectionPoolSize, String poolSize2) throws LotteryException 
	{
		init();
	}
	
	public NysLotteryGames(String gameType, int gameCount) throws LotteryException
	{
		init(gameCount);
	}
	
	public void NysLotterGames(){
		
	}
	
	private void init() throws LotteryException 
	{
		randomizer = new Randomizer(); 
		seller = "Unknown Location"; 
		this.configureGameDetail(gameName, SELECTION_COUNT, selectionPoolSize, poolSize2); 
	}
	
	private void init(int gameCount) throws LotteryException 
	{
		
		init(); 
		this.gameCount = gameCount; 

	}
	
	protected void configureGameDetail(
			String gameName, int selectionCount, int selectionPoolSize, String poolSize2) throws LotteryException
	{
	
	this.gameName = gameName; 
	this.selectionCount = selectionCount;
	NysLotteryGames.selectionPoolSize = selectionPoolSize;
	NysLotteryGames.poolSize2 = poolSize2;
	}
	
	//exception throws
	public void exceptionMethod(int gameName, int selectionPoolSize, int poolSize2) throws LotteryException {
		
		ResourceBundle bundle = null;
		
		try { 
			bundle = ResourceBundle.getBundle(this.gameName);
			}
			catch(Exception ex) {
				bundle = null; 
			}
			if(bundle == null ) {
				throw new LotteryException("Can't find: " + this.gameName, 
						LotteryException.INVALID_GAMETYPE); 
			}
					
		try { 
				bundle = ResourceBundle.getBundle(NysLotteryGames.selectionPoolSize);
			}
			catch(Exception ex) {
				bundle = null; 
			}
			if(bundle == null ) {
				throw new LotteryException("Can't find: " + NysLotteryGames.selectionPoolSize, 
						LotteryException.INVALID_POOL1); 
			}
			
		try { 
				bundle = ResourceBundle.getBundle(NysLotteryGames.poolSize2);
			}
			catch(Exception ex) {
				bundle = null; 
			}
			if(bundle == null ) {
				throw new LotteryException("Can't find: " + NysLotteryGames.poolSize2, 
						LotteryException.INVALID_POOL2); 
			}
		
	}


	//show the game. This is all from the original lab
	public void displayTicket(){
		
		//Heading 
		displayHeading();
		
		//Games
		//Shows contents of array for games
		for(int i = 0 ; i < gameCount ; ++i ) {  
			int selections[] = generateGameSelections(); 
			displayGame(i+1, selections);
		}
		
		//Footer
		displayFooter(); 
		
		return;
		
	}
		
		protected void displayHeading() {
			System.out.printf( "---------------------------------\n");
			System.out.printf( "--------  %s --------\n", gameName);
			System.out.println( "  " + new Date() + "\n" );
			
		}
		
		protected void displayFooter() {
			System.out.printf( "\n----- (c) %s -----\n", seller);
			System.out.printf( "---------------------------------\n");
			
		}
		
		protected void displayGame(int index, int [] selections) {
			
			if(index != 0)
				System.out.printf(" (%2d)  ", index);
				
			for(int i = 0 ; i < selections.length ; ++i )  {
				System.out.printf("%02d ", selections[i]);
			}
			
			System.out.printf("\n");
	}
		
		protected int[] generateGameSelections() {
			int selections[] = new int[selectionCount];
				
			int i = 0; 
			while(i < selections.length  )  {
				selections[i] = this.randomizer.generateInt(1, selectionPoolSize);
				
				// if i > 0, check for dupe. If dupe, try again ... 
				if(i > 0 ) {
						if (alreadyExists( selections, selections[i], i ) == true ) {
								// System.err.println("Found a dupe random number: " + selections[i]); 
								continue; 
						}
				}
				
				++i; 
			}
			
			Arrays.sort(selections);
			
			return selections; 
		}
		
		protected boolean alreadyExists( int [] selections, int value, int endIndex ) {
			
			for(int i = 0 ; i < endIndex ; ++i ) {
				if(value == selections[i] ) return true;
			}
			
			return false; 
		}
		
		public void setSeller(String seller) {
			this.seller = seller;
		}
		
		
	@Override
		public String toString() {
			return "NysLotteryGames [randomizer=" + randomizer + ", gameCount=" + gameCount + ", seller=" + seller
					+ ", gameName=" + gameName + ", selectionPoolSize=" + selectionPoolSize + ", selectionCount="
					+ selectionCount + ", select=" + select + "]";
		}

	
	

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		int numberOfGames = DEFAULT_GAME_COUNT;
		
		if (args.length == 0){
			System.err.println("quickpicker needs a gametype");
			System.exit(1);
		}
		
		String gameType = args[0];
		if (args.length >1) {
			numberOfGames= Integer.parseInt(args[1]);
		}
		
		try {
			NysLotteryGames game = new NysLotteryGames(gameType, numberOfGames, selectionPoolSize, poolSize2);
			game.displayTicket();
		}
		catch (LotteryException ex){
			System.err.println(ex);
			System.exit(2);
		}
			
	}

}
