package edu.cuny.csi.csc330.lab4;

import java.math.*;
import java.util.*;

import edu.cuny.csi.csc330.lab1.Randomizer;

public class DrunkWalker {
	
	private Intersection startIntersection; 
	private Intersection currentIntersection, end; //newCorner = current 
	private Randomizer randomizer;
	private Collection list; //memory
	private int avenue, street;
	
	private DrunkWalker() 
	{
		init();
	}
	
	public Collection list()
	{
		return list;
	}
	
	public DrunkWalker(int avenue, int street) 
	{
		init();
		
		list = new ArrayList<Intersection>();
		currentIntersection = new Intersection(avenue, street);
		startIntersection = new Intersection(avenue, street);
		randomizer = new Randomizer();
		list.add(currentIntersection);
	}
	
	private void init() 
	{
		
		randomizer = new Randomizer(); 
	}
	
	public void step() 
	{
		
		this.takeAStep(); 
	}
	
	
	private void takeAStep() 
	{
		
		randomizer = new Randomizer(); 
		
		switch (randomizer.generateInt(1,4))
		{
		case 1: //North
			this.street = currentIntersection.getStreet() + 1;
			this.avenue = currentIntersection.getAvenue();
			currentIntersection = new Intersection(this.avenue, this.street);
			list.add(currentIntersection);
			break;
		case 2: //East
			this.street = currentIntersection.getStreet();
			this.avenue = currentIntersection.getAvenue() +1;
			currentIntersection = new Intersection(this.avenue, this.street);
			list.add(currentIntersection);
			break;	
		case 3: //South
			this.street = currentIntersection.getStreet() - 1;
			this.avenue = currentIntersection.getAvenue();
			currentIntersection = new Intersection(this.avenue, this.street);
			list.add(currentIntersection);
			break;
		case 4: //West
			this.street = currentIntersection.getStreet();
			this.avenue = currentIntersection.getAvenue() -1;
			currentIntersection = new Intersection(this.avenue, this.street);
			list.add(currentIntersection);
			break;
		}
		
	}


	/** !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	 * toString() 
	 * @return
	 */
	public String toString() {
		return "Current Location : " + getLocation() + 
				"\nThat's "+ howFar() + " blocks from start.";
	}



	/**
	 * generate string that contains current intersection/location info 
	 */
	public String getLocation() 
	{
		
		return this.currentIntersection.toString();
		
	}

	/**
	 * Take N number of steps 
	 * @param steps
	 */
	public void fastForward(int steps ) 
	{
		
		for (int i=0; i<steps; i++)
			this.step();
	}
	
	/**
	 * Display information about this current walker instance 
	 */
	public void displayWalkDetails() 
	{
		System.out.println("\nDetails: " + this.getLocation());	
	}

	public int howFar() 
	{
	
		Iterator next = list.iterator();
		while(next.hasNext())
			end = (Intersection) next.next();
		if(startIntersection.getAvenue()> end.getAvenue())
			this.avenue = startIntersection.getAvenue() - end.getAvenue();
		else
			this.avenue = end.getAvenue() - startIntersection.getAvenue();
		if(startIntersection.getStreet()> end.getStreet())
			this.street = startIntersection.getStreet() -  end.getStreet();
		else
			this.street = end.getStreet() - startIntersection.getStreet();
		return this.avenue + this.street;
	}


	public static void main(String[] args) {
		
		// create Drunkard with initial position (ave,str)
		DrunkWalker billy = new DrunkWalker(6,23);
		
		for(int i = 1 ; i <= 3 ; ++i ) {
			billy.step(); 
			System.out.printf("billy's location after %d steps: %s\n",
					i, billy.getLocation() );
		}
			
		
		// get his current location
		String location = billy.getLocation();
		// get distance from start
		int distance = billy.howFar();
		System.out.println("Current location after fastForward(): " + location);
		System.out.println("That's " + distance + " blocks from start.");
		

		// have him move 25  random intersections
		billy = new DrunkWalker(62,16);
			System.out.println("\nBilly's " +billy);
			billy.fastForward(250);
			System.out.println("Current location after fastForward(25): "+ billy);
			//billy.displayWalkDetails();
		
			DrunkWalker ozzy = new DrunkWalker(23, 8);
			System.out.println("Starting Location: " + ozzy.getLocation());
			ozzy.fastForward(10);
			System.out.println("Ending Location: " + ozzy.getLocation());
			System.out.println("Distance(blocks): " + ozzy.howFar());
			System.out.println("Number of steps taken: "+ (ozzy.list().size() - 1));
			
			Collection checkVisited = new HashSet<Intersection>();
			for(Object obj : ozzy.list())
			{
				checkVisited.add((Intersection)obj);		
			}
			System.out.println("Number of unique intersections visited: "+ checkVisited.size());
			
			
			for(Object unique : checkVisited)
			{
				Intersection temp1 = (Intersection)unique;
				int counter=0;
				for(Object loc : ozzy.list())
				{
					Intersection temp = (Intersection)loc;
					if(temp.equals(unique))
						counter++;
				}
				System.out.println("Visited Intersection: "+ unique + " "
				+ counter+" times!");
				
			}

	}

}
